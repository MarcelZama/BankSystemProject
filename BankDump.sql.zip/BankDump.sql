-- MySQL dump 10.14  Distrib 5.5.68-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: bank
-- ------------------------------------------------------
-- Server version	5.5.68-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Current_Account`
--

DROP TABLE IF EXISTS `Current_Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Current_Account` (
  `Current_Account_Number` int(11) NOT NULL AUTO_INCREMENT,
  `Balance` float NOT NULL,
  `Overdraft_Limit` float NOT NULL,
  `Customer_Number` int(11) NOT NULL,
  `Closed` tinyint(1) NOT NULL,
  PRIMARY KEY (`Current_Account_Number`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Current_Account`
--

LOCK TABLES `Current_Account` WRITE;
/*!40000 ALTER TABLE `Current_Account` DISABLE KEYS */;
INSERT INTO `Current_Account` VALUES (1,600,85124000,7,0),(2,4500,10000,2,0),(3,1000,4000,3,0),(4,2000,4000,1,0);
/*!40000 ALTER TABLE `Current_Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Current_Account_Transaction`
--

DROP TABLE IF EXISTS `Current_Account_Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Current_Account_Transaction` (
  `Current_Account_Number` int(11) NOT NULL,
  `TransactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Current_Account_Transaction`
--

LOCK TABLES `Current_Account_Transaction` WRITE;
/*!40000 ALTER TABLE `Current_Account_Transaction` DISABLE KEYS */;
INSERT INTO `Current_Account_Transaction` VALUES (1,2),(1,5),(1,6),(1,7),(1,8),(1,9),(2,13),(3,15),(4,16),(1,17);
/*!40000 ALTER TABLE `Current_Account_Transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `Customer_Number` int(11) NOT NULL,
  `First_Name` varchar(60) NOT NULL,
  `Surname` varchar(60) NOT NULL,
  `Phone_Number` varchar(14) NOT NULL,
  `Address` text NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Occupation` varchar(60) NOT NULL,
  `Email_Address` varchar(60) NOT NULL,
  `Salary` float NOT NULL,
  `Guarantors_Name` varchar(60) NOT NULL,
  `Deleted` tinyint(1) NOT NULL,
  PRIMARY KEY (`Customer_Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES (1,'Maury','Doyle','(123)-456-7895','Wexford','1991-03-06','SoftwareDeveloper','jdoyle@gmail.com',50000,'James Murphy',0),(2,'Alex','Hawke','(085)-234-5671','Carlow','2000-03-08','Accountant','hawke@gmail.com',35000,'Jessie Doyle',0),(3,'Joe','Smith','(083)-321-9875','Kildare','2000-03-26','Driver','jsmith@gmail.com',25000,'Sarah Maher',0),(4,'Emma','Murphy','(084)-423-1987','Kilkenny','1991-03-06','Secretary','emmamurph@gmail.com',25000,'James Smith',0),(5,'John','Doyle','(085)-921-4356','Wexford','2004-03-12','Senior Engineer','jdoyleeng@gmail.com',123,'Jack Murphy',0),(6,'Jack','Murphy','(543)-781-0923','Wexford','2004-03-05','Software Developer','murphyjack@gmail.com',35000,'James Jackson',0),(7,'Kate','Smith','(083)-546-1287','Carlow','1997-03-19','Teacher','kadys@gmail.com',50000,'Jeff Lowe',0),(8,'Jack','Doyle','(083)-326-7891','Kilkenny','2004-03-03','Driver','jdriver@outlook.ie',25000,'James Murphy',0);
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Deposit_Account`
--

DROP TABLE IF EXISTS `Deposit_Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Deposit_Account` (
  `Deposit_Account_Number` int(11) NOT NULL,
  `Balance` float NOT NULL,
  `Customer_Number` int(11) NOT NULL,
  `Closed` tinyint(1) NOT NULL,
  PRIMARY KEY (`Deposit_Account_Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Deposit_Account`
--

LOCK TABLES `Deposit_Account` WRITE;
/*!40000 ALTER TABLE `Deposit_Account` DISABLE KEYS */;
INSERT INTO `Deposit_Account` VALUES (1,5500,2,0),(2,3000,4,0),(3,0,5,1),(4,1500,1,0),(5,0,7,1);
/*!40000 ALTER TABLE `Deposit_Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Deposit_Account_Transaction`
--

DROP TABLE IF EXISTS `Deposit_Account_Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Deposit_Account_Transaction` (
  `Deposit_Account_Number` int(11) NOT NULL,
  `TransactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Deposit_Account_Transaction`
--

LOCK TABLES `Deposit_Account_Transaction` WRITE;
/*!40000 ALTER TABLE `Deposit_Account_Transaction` DISABLE KEYS */;
INSERT INTO `Deposit_Account_Transaction` VALUES (2,3),(3,4),(1,1),(1,10),(4,12),(5,14);
/*!40000 ALTER TABLE `Deposit_Account_Transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Loan_Account`
--

DROP TABLE IF EXISTS `Loan_Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Loan_Account` (
  `Loan_Account_Number` int(11) NOT NULL,
  `Balance` float NOT NULL,
  `Term` date NOT NULL,
  `Monthly_repayments` float NOT NULL,
  `Customer_Number` int(11) NOT NULL,
  `Closed` tinyint(1) NOT NULL,
  PRIMARY KEY (`Loan_Account_Number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Loan_Account`
--

LOCK TABLES `Loan_Account` WRITE;
/*!40000 ALTER TABLE `Loan_Account` DISABLE KEYS */;
INSERT INTO `Loan_Account` VALUES (3,1000,'0000-00-00',0,2,0),(4,3000,'0000-00-00',0,4,0),(5,4500,'0000-00-00',0,7,0),(6,6000,'0000-00-00',0,1,0);
/*!40000 ALTER TABLE `Loan_Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Loan_Account_Transaction`
--

DROP TABLE IF EXISTS `Loan_Account_Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Loan_Account_Transaction` (
  `Loan_Account_Number` int(11) NOT NULL,
  `TransactionID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Loan_Account_Transaction`
--

LOCK TABLES `Loan_Account_Transaction` WRITE;
/*!40000 ALTER TABLE `Loan_Account_Transaction` DISABLE KEYS */;
INSERT INTO `Loan_Account_Transaction` VALUES (1,4),(2,5),(3,13),(4,14),(3,11),(4,18),(5,19),(6,20);
/*!40000 ALTER TABLE `Loan_Account_Transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rate`
--

DROP TABLE IF EXISTS `Rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rate` (
  `Rate_Type` tinytext NOT NULL,
  `Rate_Value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rate`
--

LOCK TABLES `Rate` WRITE;
/*!40000 ALTER TABLE `Rate` DISABLE KEYS */;
INSERT INTO `Rate` VALUES ('Loan Interest Rate',6),('Current Interest Rate',9),('Deposit Interest Rate',5);
/*!40000 ALTER TABLE `Rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Transaction`
--

DROP TABLE IF EXISTS `Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transaction` (
  `TransactionID` int(11) NOT NULL,
  `Date` datetime NOT NULL,
  `Type` tinytext NOT NULL,
  `Amount` float NOT NULL,
  PRIMARY KEY (`TransactionID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transaction`
--

LOCK TABLES `Transaction` WRITE;
/*!40000 ALTER TABLE `Transaction` DISABLE KEYS */;
INSERT INTO `Transaction` VALUES (1,'2022-03-26 19:30:16','Lodgement',5000),(2,'2022-03-26 19:30:27','Current',4900),(3,'2022-03-26 19:30:29','Lodgement',3000),(4,'2022-03-26 19:31:42','Lodgement',0),(5,'2022-03-26 19:36:57','Withdrawals',100),(6,'2022-03-26 19:40:55','Withdrawals',1000),(7,'2022-03-26 19:43:50','Withdrawals',150),(8,'2022-03-26 19:43:57','Withdrawals',150),(9,'2022-03-26 20:15:41','Withdrawals',2000),(10,'2022-03-26 20:56:50','Lodgement',500),(11,'2022-03-26 22:19:55','Loan',1000),(12,'2022-03-26 22:38:02','Lodgement',1500),(13,'2022-03-27 00:28:25','Lodgement',4500),(14,'2022-03-27 10:05:15','Lodgement',0),(15,'2022-03-27 12:26:20','Lodgement',1000),(16,'2022-03-27 12:26:53','Lodgement',2000),(17,'2022-03-27 13:29:04','Withdrawals',100),(18,'2022-03-27 16:55:44','Loan',3000),(19,'2022-03-27 16:56:09','Loan',4500),(20,'2022-03-27 16:56:33','Loan',6000);
/*!40000 ALTER TABLE `Transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-03-28 11:40:35
