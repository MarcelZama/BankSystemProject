<html>
  <head>
    <title>Loan Account Menu</title>
  </head>
  <body>	  	
<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?>
	</div>
	  
<ul id="navlist">
	<li><a href="/bank/Ming/openAccount.html.php">Open an Account</a></li>
	<li><a href="/bank/Ming/closeAccount.html.php">Close an Account</a></li>
    <li><a href="/bank/Ming/amendView.html.php">View / Amend an Account</a></li>
    <li><a href="/bank/Ming/LoanHistory.html.php">Loan Account History</a></li>
</ul>
  </body>
</html>