<html>
  <head>
    <title>Report Menu</title>
  </head>
  <body>	  	
<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?>
	</div>
	  
<ul id="navlist">
	<li><a href="/bank/Yvonne/depositHistory.html.php">Deposit Account History </a></li>
	<li><a href="/bank/Ming/LoanHistory.html.php">Loan Account History</a></li>
    <li><a href="/bank/Ming/">Currrent Account History</a></li>
	<li><a href="/bank/Ming/">Customer Report</a></li>
	<li><a href="/bank/Ming/">Current Account Interest Report</a></li>
    <li><a href="/bank/Ming/Report/AccountReport.html.php">Account Report</a></li>
    
</ul>
	  
  </body>
</html>