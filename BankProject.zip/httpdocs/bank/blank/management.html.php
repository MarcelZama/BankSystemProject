<html>
  <head>
    <title>Management</title>
  </head>
  <body>
		<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?></div>
  </body>
</html>