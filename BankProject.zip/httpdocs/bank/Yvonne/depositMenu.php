<html>
<!-- Author:	Yvonne Ryan	- C00263872							!-->
<!-- Date:		Feb 2022										!-->
<!-- Purpose:	Submenu displaying Deposit Account options		!-->
<!-- Title:		depositMenu.php									!-->
  <head>
    <title>Deposit Account Menu</title>
  </head>
  <body>	  	
<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?>
	</div>
	  
<ul id="navlist">
	<li><a href="/bank/Yvonne/openAccount.html.php">Open Deposit Account</a></li>
    <li><a href="View.html.php">View Deposit Account</a></li>
	<li><a href="closeAccount.html.php">Close Deposit Account</a></li>
	<li><a href="depositHistory.html.php">Deposit Account History</a></li>
		   </ul>
	  
  </body>
</html>