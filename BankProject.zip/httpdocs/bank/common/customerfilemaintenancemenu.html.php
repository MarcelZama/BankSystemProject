<!--
Purpose:
	Customer Submenu that links to all of the operations of the Customer the user can perform
-->
<html>
  <head><title>Account Maintenance</title></head>
<body><div><?php include "menu.html.php"?></div> <!-- Including the main menu -->	 
	<!-- Customer Submenu Links -->
<ul>
	<li><a href="/bank/David/addcustomer.html.php">Add New Customer</a></li>
    <li><a href="/bank/David/amendview.html.php">View / Amend Customer</a></li>
    <li><a href="/bank/David/deleteCustomer.html.php">Delete Customer</a></li>
</ul>
</body>
</html>