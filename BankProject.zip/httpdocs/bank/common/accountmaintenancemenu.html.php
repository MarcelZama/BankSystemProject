<!--
Purpose:
	Account Submenu that links to other Account Submenus
-->
<html>
<head><title>Account Maintenance</title></head>
<!-- Including the main menu -->
<body><div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?></div> 
	<!-- Account Submenu Links -->
<ul>
	<li><a href="/bank/Yvonne/depositMenu.php">Deposit Account Menu</a></li>
    <li><a href="/bank/Ming/LoanOption.php">Loan Account Menu</a></li>
	<li><a href="/bank/Marcel/currentOptions.php">Current Account Menu</a></li>
</ul>  
</body>
</html>