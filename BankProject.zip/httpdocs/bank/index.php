<!-- Can't affix this with html.php, despite being mostly html, otherwise url/bank leads to protected files -->
<html>
  <head>
    <title>Home Page</title>
  </head>
  <body>
		<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?></div>
  </body>
</html>
