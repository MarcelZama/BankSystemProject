<html>
  <head>
    <title>Current Account Menu</title>
  </head>
  <body>	  	
<div><?php include $_SERVER['DOCUMENT_ROOT'] . "/bank/common/menu.html.php"?>
	</div>
	  
<ul id="navlist">
	<li><a href="/bank/Marcel/OpenCurrentAccount.html.php">Open a Current Account</a></li>
	<li><a href="/bank/Marcel/closeCurrentAccount.html.php">Close a Current Account</a></li>
    <li><a href="/bank/Marcel/viewAmend.html.php">View or Amend Account</a></li>    
	<li><a href="/bank/Marcel/Withdrawals.html.php">Withdrawals</a></li> 
</ul>
	  
  </body>
</html>
